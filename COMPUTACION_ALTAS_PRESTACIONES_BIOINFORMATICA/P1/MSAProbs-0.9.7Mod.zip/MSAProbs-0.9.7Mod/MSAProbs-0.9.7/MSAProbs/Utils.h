/*
 * Utils.h
 *
 *  Created on: Dec 23, 2011
 *      Author: yongchao
 */

#ifndef UTILS_H_
#define UTILS_H_

#include <stdlib.h>
#include <stdio.h>

class Utils
{
public:
	static double getSysTime();
};

#endif /* UTILS_H_ */
