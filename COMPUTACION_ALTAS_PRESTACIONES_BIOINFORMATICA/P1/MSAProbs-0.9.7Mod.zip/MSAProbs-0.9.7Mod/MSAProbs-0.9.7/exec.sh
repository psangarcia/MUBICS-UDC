MSAProbs/msaprobs ../tests/bb3_release/RV11/BB1*.tfa -num_threads 1 -o ../tests/bb3_release/RV11/outMSAProbs.txt
