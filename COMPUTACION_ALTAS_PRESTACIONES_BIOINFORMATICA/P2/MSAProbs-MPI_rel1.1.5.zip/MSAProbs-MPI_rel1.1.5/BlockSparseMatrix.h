/*
 * BlockSparseMatrix.h
 *
 *  Created on: 13/1/2016
 *      Author: jorge
 */

#ifndef BLOCKSPARSEMATRIX_H_
#define BLOCKSPARSEMATRIX_H_

#include "SafeVector.h"
#include "SparseMatrix.h"

#include <stdint.h>

class BlockSparseMatrix {
public:
	BlockSparseMatrix();
	BlockSparseMatrix(int numMatrices, SafeVector<SparseMatrix *> sparseMatrices);
	virtual ~BlockSparseMatrix();

	int GetNumMatrices(){
		return _numMatrices;
	}

	int GetNumInts(){
		return _numInts;
	}

	int *GetIntBuffer(){
		return _intBuffer;
	}

	int GetNumData(){
		return _blockData;
	}

	float *GetData(){
		return _data;
	}

	void loadMatrices(int numMatrices, SafeVector<SparseMatrix *> sparseMatrices);

private:
	int _numMatrices;	// Number of matrices in the block
	uint64_t _numInts; 		// Total number of integers in the buffer (necessary for sending)
	int *_intBuffer; 	// Buffer with the integer information. For each matrix:
						// The first 2 values are the dimensions
						// The next vale is the number of nonzero elements of the matrix
						// The next values are the number of cells for each row of each matrix ("rowSizes" in SparseMatrix)
						// The next elements are the columns for value

	uint64_t _allocInt; 		// Number of integers allocated in the buffer
	uint64_t _blockData; 	// Total amount of data in the block (necessary for sending)
	float *_data;
	uint64_t _allocData;		// Number of floats allocated in the buffer

	void checkMemoryInt(uint64_t numElements){
		if(numElements > _allocInt){
			int *aux = new int[numElements*2];
			memcpy(aux, _intBuffer, _allocInt*sizeof(int));
			delete [] _intBuffer;
			_intBuffer = aux;
			_allocInt = numElements*2;
		}
	}

	void checkMemoryData(uint64_t numElements){
		if(numElements > _allocData){
			float *aux = new float[numElements*2];
			memcpy(aux, _data, _allocData*sizeof(float));
			delete [] _data;
			_data = aux;
			_allocData = numElements*2;
		}
	}
};

#endif /* BLOCKSPARSEMATRIX_H_ */
