/*
 * BlockSparseMatrix.cpp
 *
 *  Created on: 13/1/2016
 *      Author: jorge
 */

#include "BlockSparseMatrix.h"

BlockSparseMatrix::BlockSparseMatrix() {
	_numMatrices = 0;
	_allocInt = 0;
	_allocData = 0;
	_numInts = 0;
	_intBuffer = NULL;
	_blockData = 0;
	_data = NULL;

}

BlockSparseMatrix::BlockSparseMatrix(int numMatrices, SafeVector<SparseMatrix *> sparseMatrices){

	_numMatrices = 0;
	_allocInt = 0;
	_allocData = 0;
	_intBuffer = NULL;
	_data = NULL;

	loadMatrices(numMatrices, sparseMatrices);
}

BlockSparseMatrix::~BlockSparseMatrix() {
	_numMatrices = 0;
	_allocInt = 0;
	_allocData = 0;
	_numInts = 0;
	_blockData = 0;

	_intBuffer = NULL;
	_data = NULL;

	/*if(_intBuffer != NULL){
		delete [] _intBuffer;
	}

	if(_data != NULL){
		delete [] _data;
	}*/
}

void BlockSparseMatrix::loadMatrices(int numMatrices, SafeVector<SparseMatrix *> sparseMatrices){
	_numMatrices = numMatrices;
	_numInts = 0;
	_blockData = 0;

	checkMemoryInt(3*numMatrices);

	SparseMatrix *sp;
	uint64_t numRows, numData;

	for(int i=0; i<numMatrices; i++){
		sp = sparseMatrices[i];
		numRows = sp->GetSeq1Length()+1;
		numData = sp->GetNumCells();

		checkMemoryInt(_numInts+3+numRows+numData);
		checkMemoryData(_blockData+numData);

		_intBuffer[_numInts++] = numRows;
		_intBuffer[_numInts++] = sp->GetSeq2Length()+1;
		_intBuffer[_numInts++] = numData;

		memcpy(&_intBuffer[_numInts], sp->GetRowSizes(), numRows*sizeof(int));
		_numInts += numRows;

		for(int j=0; j<numData; j++){
			_intBuffer[_numInts++] = sp->GetColumn(j);
			_data[_blockData++] = sp->GetValue(j);
		}
	}
}
