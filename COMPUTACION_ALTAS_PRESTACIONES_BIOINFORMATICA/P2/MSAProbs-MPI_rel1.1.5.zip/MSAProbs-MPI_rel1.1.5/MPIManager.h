/*
 * MPIManager.h
 *
 *  Created on: 12/1/2016
 *      Author: jorge
 */

#ifndef MPIMANAGER_H_
#define MPIMANAGER_H_

#include "BlockSparseMatrix.h"

#include <algorithm>
#include <numeric>

#include "mpi.h"

using namespace std;

//private struct
struct SeqsPair {
	int seq1;
	int seq2;
};

class MPIManager {
public:
	MPIManager();
	MPIManager(int source);
	virtual ~MPIManager();

	// Function to send a fragment of the distance matrix to the source
	// It must not be called by the source process
	void SendDistanceMatrix(VF myDistances, int numPairs);

	// Function to receive the fragments of the distance matrix
	// It must be called only by the source process
	void RecvDistanceMatrix(VVF& distances, VF myDistances, int numSeqs, int* firstRow, int *numRows, int *numPairs,
			SeqsPair *seqsPair);

	// Function to find and the maximum amount of data in the blocks of the processes and allocate the buffers
	void PrepareRing(BlockSparseMatrix mySparseMatrices);

	// Function to send a block of sparse matrices
	void SendBlockSparseMatrices(BlockSparseMatrix mySparseMatrices, int distance);

	// Function to receive the blocks of sparse matrices into the array of matrices
	// The message could have been previously received into the buffer
	// It returns the source of the data
	int RecvBlockSparseMatrices(SafeVector<SparseMatrix *> &buffer, int distance, int *numPairs);

	// Function to send a block of sparse matrices when gathering the transformations
	// It must not be called by the source process
	void SendBlockTransSparseMatrices(BlockSparseMatrix mySparseMatrices);

	// Function to receive the blocks of sparse matrices when gathering the transformation
	// It must be called only by the source process
	void RecvBlockTransSparseMatrices(SafeVector<SafeVector<SparseMatrix *> > &sparseMatrices,
			BlockSparseMatrix mySparseMatrices, int numSeqs, int maxLength, int* firstRow, int *numRows, int *numPairs,
			SeqsPair *seqsPair);

	// Function to broadcast the values of seqsWeigth
	// It must be called by all processes
	void BcastWeights(int *seqsWeights, int numSeqs);

private:
	void SaveDistValues(VVF& distances, float *buffer, int numSeqs, int firstRow, int numRows,
			int firstPair, SeqsPair *seqsPairs, int numPairs);

	void SaveSparseMatrices(SafeVector<SparseMatrix *> &sparseMatrices, int numPairs, int offset);

	void SaveTransSparseMatrices(SafeVector<SafeVector<SparseMatrix *> > &sparseMatrices, int *bufferInt,
			float *bufferData, int numSeqs, int maxLength, int firstRow, int numRows,
			int firstPair, SeqsPair *seqsPairs, int numPairs);

	int _source;
	int *_bufferInt;
	float *_bufferData;
	int _maxSize;
	MPI_Request _reqInt;
	MPI_Request _reqData;
};

#endif /* MPIMANAGER_H_ */
