/*
 * MPIManager.cpp
 *
 *  Created on: 12/1/2016
 *      Author: jorge
 */

#include "MPIManager.h"

MPIManager::MPIManager() {
	_source = 0;
	_bufferInt = NULL;
	_bufferData = NULL;
	_maxSize = 0;
}

MPIManager::MPIManager(int source) {
	_source = source;
	_bufferInt = NULL;
	_bufferData = NULL;
	_maxSize = 0;
}

MPIManager::~MPIManager() {

	if(_bufferInt != NULL){
		delete [] _bufferInt;
	}

	if(_bufferData != NULL){
		delete [] _bufferData;
	}
}

void MPIManager::SendDistanceMatrix(VF myDistances, int numPairs){

	float *buffer = myDistances.data();
	MPI_Send(buffer, numPairs, MPI_INT, _source, 0, MPI_COMM_WORLD);
}

void MPIManager::RecvDistanceMatrix(VVF& distances, VF myDistances, int numSeqs, int* firstRow, int *numRows, int *numPairs,
		SeqsPair *seqsPair){

	// Get the number of processes
	int numP;
	MPI_Comm_size(MPI_COMM_WORLD, &numP);
	int maxSize = *std::max_element(numPairs, numPairs+numP);
	MPI_Status st;

	float *buffer = new float[maxSize];
	int *partialSum = new int[numP];
	partialSum[0] = 0;
	partial_sum(numPairs, numPairs+numP, &partialSum[1]);

	// Copy the elements of the source
	SaveDistValues(distances, myDistances.data(), numSeqs, firstRow[_source], numRows[_source],
			partialSum[_source], seqsPair, numPairs[_source]);

    for(int i=1; i<numP; i++){
    	// Receive and copy the elements of the other processes
    	MPI_Recv(buffer, maxSize, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &st);

    	SaveDistValues(distances, buffer, numSeqs, firstRow[st.MPI_SOURCE], numRows[st.MPI_SOURCE],
    			partialSum[st.MPI_SOURCE], seqsPair, numPairs[st.MPI_SOURCE]);
    }

	delete [] buffer;
	delete [] partialSum;
}

void MPIManager::SaveDistValues(VVF& distances, float *buffer, int numSeqs, int firstRow, int numRows,
		int firstPair, SeqsPair *seqsPairs, int numPairs){

	int iterDist;
#ifdef _OPENMP
#pragma omp parallel for private(iterDist) default(shared) schedule(dynamic)
	for(iterDist = 0; iterDist < numPairs; iterDist++) {
		int a= seqsPairs[firstPair+iterDist].seq1;
		int b = seqsPairs[firstPair+iterDist].seq2;
#else
	iterDist = 0;
	for(int a = firstRow; a < firstRow+numRows; a++){
		for(int b = a+1; b < numSeqs; b++){
#endif
			distances[a][b] = distances[b][a] = buffer[iterDist];
#ifndef _OPENMP
			iterDist++;
		}
#endif
	}

}

void MPIManager::PrepareRing(BlockSparseMatrix mySparseMatrices){

	int mySize = mySparseMatrices.GetNumInts();

	MPI_Allreduce(&mySize, &_maxSize, 1, MPI_INT, MPI_MAX, MPI_COMM_WORLD);

	_bufferInt = new int[_maxSize];
	_bufferData = new float[_maxSize];
}

void MPIManager::SendBlockSparseMatrices(BlockSparseMatrix mySparseMatrices, int distance){

	// Get the number of processes
	int numP;
	MPI_Comm_size(MPI_COMM_WORLD, &numP);
	// Get the ID of the process
	int myId;
	MPI_Comm_rank(MPI_COMM_WORLD, &myId);

	int dest = (myId+distance)%numP;

	// First we send the messages
	MPI_Isend(mySparseMatrices.GetIntBuffer(), mySparseMatrices.GetNumInts(), MPI_INT, dest, 1, MPI_COMM_WORLD, NULL);
	MPI_Isend(mySparseMatrices.GetData(), mySparseMatrices.GetNumData(), MPI_FLOAT, dest, 2, MPI_COMM_WORLD, NULL);

	int src = myId-distance;
	if(src < 0){
		src = numP+src;
	}

	// Now we start receiving the messages
	MPI_Irecv(_bufferInt, _maxSize, MPI_INT, src, 1, MPI_COMM_WORLD, &_reqInt);
	MPI_Irecv(_bufferData, _maxSize, MPI_FLOAT, src, 2, MPI_COMM_WORLD, &_reqData);
}

int MPIManager::RecvBlockSparseMatrices(SafeVector<SparseMatrix*> &sparseMatrices, int distance, int *numPairs){

	// Get the number of processes
	int numP;
	MPI_Comm_size(MPI_COMM_WORLD, &numP);
	// Get the ID of the process
	int myId;
	MPI_Comm_rank(MPI_COMM_WORLD, &myId);

	int src = myId-distance;
	if(src < 0){
		src = numP+src;
	}

	int offsetBuffer = 0;
	for(int i=0; i<src; i++){
		offsetBuffer += numPairs[i];
	}

	MPI_Wait(&_reqInt, NULL);
	MPI_Wait(&_reqData, NULL);

	// Put the data into the matrices
	SaveSparseMatrices(sparseMatrices, numPairs[src], offsetBuffer);

	return src;
}

void MPIManager::SaveSparseMatrices(SafeVector<SparseMatrix *> &sparseMatrices, int numPairs, int offset){

	int *iterBufferInt = _bufferInt;
	float *iterBufferData = _bufferData;
	int iterPair;
	int prevPair = 0;
	int length1, numCells;
	SparseMatrix *sp;

#ifdef _OPENMP
#pragma omp parallel for private(iterPair, sp, length1, numCells) firstprivate(iterBufferInt, iterBufferData, prevPair) default(shared) schedule(dynamic)
#endif
	for(iterPair = 0; iterPair < numPairs; iterPair++) {
			sp = new SparseMatrix();

			for(int i=prevPair; i<iterPair; i++){
				length1 = iterBufferInt[0]-1;
				numCells = iterBufferInt[2];
				iterBufferInt += 4+length1+numCells;
				iterBufferData += numCells;
			}

			sp->SetInfo(iterBufferInt[0]-1, iterBufferInt[1]-1, iterBufferInt[2], &iterBufferInt[3],
					&iterBufferInt[4+iterBufferInt[0]-1], iterBufferData);

			sparseMatrices[iterPair+offset] = sp;

			prevPair = iterPair;
	}
}

void MPIManager::SendBlockTransSparseMatrices(BlockSparseMatrix mySparseMatrices){

	MPI_Send(mySparseMatrices.GetIntBuffer(), mySparseMatrices.GetNumInts(), MPI_INT, _source, 1, MPI_COMM_WORLD);
	MPI_Send(mySparseMatrices.GetData(), mySparseMatrices.GetNumData(), MPI_FLOAT, _source, 2, MPI_COMM_WORLD);
}

void MPIManager::RecvBlockTransSparseMatrices(SafeVector<SafeVector<SparseMatrix *> > &sparseMatrices,
		BlockSparseMatrix mySparseMatrices, int numSeqs, int maxLength, int* firstRow, int *numRows, int *numPairs,
		SeqsPair *seqsPairs){

	// Get the number of processes
	int numP;
	MPI_Comm_size(MPI_COMM_WORLD, &numP);
	MPI_Status st;

	// This more than enough memory for the computations
	int *bufferInt = new int[_maxSize];
	float *bufferData = new float[_maxSize];
	int *partialSum = new int[numP];
	partialSum[0] = 0;
	partial_sum(numPairs, numPairs+numP, &partialSum[1]);

	// Copy the elements of the source
	SaveTransSparseMatrices(sparseMatrices, mySparseMatrices.GetIntBuffer(), mySparseMatrices.GetData(), numSeqs, maxLength,
			firstRow[_source], numRows[_source], partialSum[_source], seqsPairs, numPairs[_source]);

    for(int i=1; i<numP; i++){
    	// Receive and copy the elements of the other processes
    	MPI_Recv(bufferInt, _maxSize, MPI_INT, MPI_ANY_SOURCE, 1, MPI_COMM_WORLD, &st);
    	MPI_Recv(bufferData, _maxSize, MPI_FLOAT, st.MPI_SOURCE, 2, MPI_COMM_WORLD, NULL);
    	SaveTransSparseMatrices(sparseMatrices, bufferInt, bufferData, numSeqs, maxLength,
    			firstRow[st.MPI_SOURCE], numRows[st.MPI_SOURCE],
    			partialSum[st.MPI_SOURCE], seqsPairs, numPairs[st.MPI_SOURCE]);
    }

	delete [] bufferInt;
	delete [] bufferData;
	delete [] partialSum;
}

void MPIManager::SaveTransSparseMatrices(SafeVector<SafeVector<SparseMatrix *> > &sparseMatrices, int *bufferInt,
		float *bufferData, int numSeqs, int maxLength, int firstRow, int numRows,
		int firstPair, SeqsPair *seqsPairs, int numPairs){

	int *iterBufferInt = bufferInt;
	float *iterBufferData = bufferData;
	int iterPair;
	int prevPair = 0;
	int length1, numCells;
	SparseMatrix *sp;

#ifdef _OPENMP
#pragma omp parallel for private(iterPair, sp, length1, numCells) firstprivate(iterBufferInt, iterBufferData, prevPair) default(shared) schedule(dynamic)
	for(iterPair = 0; iterPair < numPairs; iterPair++) {
		int a= seqsPairs[firstPair+iterPair].seq1;
		int b = seqsPairs[firstPair+iterPair].seq2;
#else
	iterPair = 0;
	for(int a = firstRow; a < firstRow+numRows; a++){
		for(int b = a+1; b < numSeqs; b++){
#endif
			sp = new SparseMatrix();

			for(int i=prevPair; i<iterPair; i++){
				length1 = iterBufferInt[0]-1;
				numCells = iterBufferInt[2];
				iterBufferInt += 4+length1+numCells;
				iterBufferData += numCells;
			}

			sp->SetInfo(iterBufferInt[0]-1, iterBufferInt[1]-1, iterBufferInt[2], &iterBufferInt[3],
					&iterBufferInt[4+iterBufferInt[0]-1], iterBufferData);

			sparseMatrices[a][b] = sp;
			sparseMatrices[b][a] = NULL;

			prevPair = iterPair;

#ifndef _OPENMP
			iterPair++;
		}
#endif
	}
}

void MPIManager::BcastWeights(int *seqsWeights, int numSeqs){
	MPI_Bcast(seqsWeights, numSeqs, MPI_INT, _source, MPI_COMM_WORLD);
}
