/*
 * Utils.cpp
 *
 *  Created on: Dec 23, 2011
 *      Author: yongchao
 */

#include "Utils.h"
#include <sys/time.h>

double Utils::getSysTime()
{
	double dtime;
	struct timeval tv;

	gettimeofday(&tv, NULL);

	dtime = (double) tv.tv_sec;
	dtime += (double) (tv.tv_usec) / 1000000.0;

	return dtime;

}

