/***********************************************
 * # Copyright 2009-2010. Liu Yongchao
 * # Contact: Liu Yongchao, School of Computer Engineering,
 * #			 Nanyang Technological University.
 * # Emails:	 liuy0039@ntu.edu.sg; nkcslyc@hotmail.com
 * #
 * # GPL version 3.0 applies.
 * #
 * ************************************************/
#include "MSA.h"

int main(int argc, char* argv[]) {

	// Initialize MPI
	MPI_Init(&argc, &argv);

	MSA msa(argc, argv);

	// Terminate MPI
	MPI_Finalize();

	return 0;
}
